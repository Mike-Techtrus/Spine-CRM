import type { ButtonHTMLAttributes, InputHTMLAttributes, ReactNode, SelectHTMLAttributes, TextareaHTMLAttributes } from 'react'

export function Button({
  variant = 'primary',
  className = '',
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'secondary' | 'danger' }) {
  const base =
    'inline-flex items-center justify-center gap-2 rounded-lg px-4 py-2.5 text-sm font-semibold transition-colors disabled:opacity-50 disabled:cursor-not-allowed'
  const variants = {
    primary: 'bg-accent text-accent-contrast hover:bg-accent-strong',
    secondary: 'bg-transparent text-text border border-border-strong hover:border-accent hover:text-accent',
    danger: 'bg-danger text-text hover:bg-danger-strong',
  }
  return <button className={`${base} ${variants[variant]} ${className}`} {...props} />
}

export function Input(props: InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      {...props}
      className={`w-full rounded-md border border-border bg-sunken px-3 py-2 text-sm text-text placeholder:text-text-faint focus:border-accent focus:outline-none ${props.className ?? ''}`}
    />
  )
}

export function Textarea(props: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <textarea
      {...props}
      className={`w-full rounded-md border border-border bg-sunken px-3 py-2 text-sm text-text placeholder:text-text-faint focus:border-accent focus:outline-none ${props.className ?? ''}`}
    />
  )
}

export function Select(props: SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select
      {...props}
      className={`w-full rounded-md border border-border bg-sunken px-3 py-2 text-sm text-text focus:border-accent focus:outline-none ${props.className ?? ''}`}
    />
  )
}

export function Label({ children }: { children: ReactNode }) {
  return <label className="mb-1 block text-xs font-mono-label text-text-dim">{children}</label>
}

export function Eyebrow({ children }: { children: ReactNode }) {
  return <span className="eyebrow">{children}</span>
}

export function Card({ children, className = '' }: { children: ReactNode; className?: string }) {
  return (
    <div className={`rounded-xl border border-border bg-surface p-5 shadow-[0_1px_0_0_rgba(0,0,0,0.3)] ${className}`}>
      {children}
    </div>
  )
}

const STATUS_STYLES: Record<string, string> = {
  draft: 'bg-surface-raised text-text-muted border-border-strong',
  submitted: 'bg-warning/10 text-warning border-warning/40',
  approved: 'bg-accent/10 text-accent border-accent/40',
  rejected: 'bg-danger/10 text-danger border-danger/40',
}

export function StatusBadge({ status, label }: { status: string; label: string }) {
  return (
    <span
      className={`inline-block rounded-full border px-2.5 py-0.5 text-xs font-mono-label uppercase tracking-wide ${STATUS_STYLES[status] ?? STATUS_STYLES.draft}`}
    >
      {label}
    </span>
  )
}

export function ErrorText({ children }: { children: ReactNode }) {
  if (!children) return null
  return <p className="text-sm text-danger">{children}</p>
}

export function StatTile({
  value,
  label,
  accent = false,
}: {
  value: ReactNode
  label: string
  accent?: boolean
}) {
  return (
    <div className="rounded-lg border border-border bg-sunken px-4 py-3">
      <p className={`font-display text-2xl font-semibold ${accent ? 'text-accent' : 'text-text'}`}>{value}</p>
      <p className="mt-0.5 text-xs font-mono-label text-text-dim">{label}</p>
    </div>
  )
}

export function DottedRule({ className = '' }: { className?: string }) {
  return <div className={`dotted-rule ${className}`} />
}
