import { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { listInvoices } from '../../lib/api'
import type { InvoiceWithRelations } from '../../lib/types'
import { INVOICE_STATUS_LABELS } from '../../lib/types'
import { Button, Card, StatusBadge } from '../../components/ui'

const STATUS_BADGE_MAP: Record<string, string> = {
  draft: 'draft',
  sent: 'submitted',
  paid: 'approved',
  cancelled: 'rejected',
}

export default function InvoiceList() {
  const navigate = useNavigate()
  const [invoices, setInvoices] = useState<InvoiceWithRelations[] | null>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    listInvoices()
      .then(setInvoices)
      .catch((err) => setError(err instanceof Error ? err.message : 'Failed to load.'))
  }, [])

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-xl font-semibold text-text">Invoices</h1>
        <Link to="/staff/invoices/new">
          <Button>New invoice</Button>
        </Link>
      </div>

      {error && <p className="text-sm text-danger">{error}</p>}
      {!invoices && !error && <p className="text-sm text-text-muted">Loading…</p>}
      {invoices && invoices.length === 0 && (
        <Card>
          <p className="text-sm text-text-muted">No invoices yet.</p>
        </Card>
      )}

      {invoices && invoices.length > 0 && (
        <div className="overflow-hidden rounded-lg border border-border">
          <table className="w-full text-sm">
            <thead className="bg-surface-raised text-left text-xs font-mono-label text-text-muted">
              <tr>
                <th className="px-4 py-2">Invoice #</th>
                <th className="px-4 py-2">Client</th>
                <th className="px-4 py-2">Due date</th>
                <th className="px-4 py-2">Total</th>
                <th className="px-4 py-2">Status</th>
              </tr>
            </thead>
            <tbody>
              {invoices.map((inv) => (
                <tr
                  key={inv.id}
                  className="cursor-pointer border-t border-border hover:bg-surface-raised"
                  onClick={() => navigate(`/staff/invoices/${inv.id}`)}
                >
                  <td className="px-4 py-2 font-mono-label text-text-muted">{inv.invoice_number}</td>
                  <td className="px-4 py-2 text-text">{inv.client?.name || '—'}</td>
                  <td className="px-4 py-2 text-text-muted">{inv.due_date || '—'}</td>
                  <td className="px-4 py-2 text-text-muted">
                    {inv.total ? `£${Number(inv.total).toLocaleString('en-GB')}` : '—'}
                  </td>
                  <td className="px-4 py-2">
                    <StatusBadge status={STATUS_BADGE_MAP[inv.status]} label={INVOICE_STATUS_LABELS[inv.status]} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
