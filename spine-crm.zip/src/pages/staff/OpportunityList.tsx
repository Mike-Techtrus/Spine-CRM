import { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { listOpportunities } from '../../lib/api'
import type { OpportunityWithRelations } from '../../lib/types'
import { OPPORTUNITY_STAGE_LABELS } from '../../lib/types'
import { Button, Card } from '../../components/ui'

export default function OpportunityList() {
  const navigate = useNavigate()
  const [opportunities, setOpportunities] = useState<OpportunityWithRelations[] | null>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    listOpportunities()
      .then(setOpportunities)
      .catch((err) => setError(err instanceof Error ? err.message : 'Failed to load.'))
  }, [])

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-xl font-semibold text-text">Opportunities</h1>
        <Link to="/staff/opportunities/new">
          <Button>New opportunity</Button>
        </Link>
      </div>

      {error && <p className="text-sm text-danger">{error}</p>}
      {!opportunities && !error && <p className="text-sm text-text-muted">Loading…</p>}

      {opportunities && opportunities.length === 0 && (
        <Card>
          <p className="text-sm text-text-muted">No opportunities yet.</p>
        </Card>
      )}

      {opportunities && opportunities.length > 0 && (
        <div className="overflow-hidden rounded-lg border border-border">
          <table className="w-full text-sm">
            <thead className="bg-surface-raised text-left text-xs font-mono-label text-text-muted">
              <tr>
                <th className="px-4 py-2">Name</th>
                <th className="px-4 py-2">End client</th>
                <th className="px-4 py-2">Stage</th>
                <th className="px-4 py-2">Est. value</th>
                <th className="px-4 py-2">Expected close</th>
              </tr>
            </thead>
            <tbody>
              {opportunities.map((o) => (
                <tr
                  key={o.id}
                  className="cursor-pointer border-t border-border hover:bg-surface-raised"
                  onClick={() => navigate(`/staff/opportunities/${o.id}`)}
                >
                  <td className="px-4 py-2 text-text">{o.name}</td>
                  <td className="px-4 py-2 text-text-muted">{o.end_client?.name || '—'}</td>
                  <td className="px-4 py-2 text-text-muted">{OPPORTUNITY_STAGE_LABELS[o.stage]}</td>
                  <td className="px-4 py-2 text-text-muted">
                    {o.estimated_value ? `£${Number(o.estimated_value).toLocaleString('en-GB')}` : '—'}
                  </td>
                  <td className="px-4 py-2 text-text-muted">{o.expected_close_date || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
