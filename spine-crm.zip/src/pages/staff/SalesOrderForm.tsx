import { useEffect, useState, type SyntheticEvent } from 'react'
import { useNavigate, useParams, useSearchParams } from 'react-router-dom'
import {
  createSalesOrder,
  getQuoteForConversion,
  getSalesOrder,
  listAccounts,
  updateSalesOrder,
} from '../../lib/api'
import type { Account } from '../../lib/types'
import { Button, Card, ErrorText, Input, Label, Select, Textarea } from '../../components/ui'

const emptyForm = {
  quote_id: '',
  client_id: '',
  end_client_id: '',
  po_number: '',
  po_received_date: '',
  start_date: '',
  end_date: '',
  quote_value: '',
  po_value: '',
  difference: '',
  quote_match: false,
  vat: '',
  total: '',
  rebate: '',
  net_value: '',
  invoiced_to_date: '',
  outstanding_comments: '',
}

export default function SalesOrderForm() {
  const { id } = useParams()
  const [searchParams] = useSearchParams()
  const quoteIdFromQuery = searchParams.get('quoteId')
  const isEditing = Boolean(id)
  const navigate = useNavigate()

  const [accounts, setAccounts] = useState<Account[]>([])
  const [reference, setReference] = useState<string | null>(null)
  const [form, setForm] = useState(emptyForm)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    ;(async () => {
      try {
        setAccounts(await listAccounts(true))

        if (id) {
          const so = await getSalesOrder(id)
          setReference(so.reference)
          setForm({
            quote_id: so.quote_id ?? '',
            client_id: so.client_id ?? '',
            end_client_id: so.end_client_id ?? '',
            po_number: so.po_number ?? '',
            po_received_date: so.po_received_date ?? '',
            start_date: so.start_date ?? '',
            end_date: so.end_date ?? '',
            quote_value: so.quote_value?.toString() ?? '',
            po_value: so.po_value?.toString() ?? '',
            difference: so.difference?.toString() ?? '',
            quote_match: so.quote_match,
            vat: so.vat?.toString() ?? '',
            total: so.total?.toString() ?? '',
            rebate: so.rebate?.toString() ?? '',
            net_value: so.net_value?.toString() ?? '',
            invoiced_to_date: so.invoiced_to_date?.toString() ?? '',
            outstanding_comments: so.outstanding_comments ?? '',
          })
        } else if (quoteIdFromQuery) {
          const q = await getQuoteForConversion(quoteIdFromQuery)
          setForm({
            ...emptyForm,
            quote_id: q.id,
            client_id: q.client_id ?? '',
            end_client_id: q.end_client_id ?? '',
            start_date: q.start_date ?? '',
            end_date: q.end_date ?? '',
            quote_value: q.value?.toString() ?? '',
            vat: q.vat?.toString() ?? '',
            total: q.total?.toString() ?? '',
            rebate: q.rebate?.toString() ?? '',
            net_value: q.net_value?.toString() ?? '',
          })
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load.')
      } finally {
        setLoading(false)
      }
    })()
  }, [id, quoteIdFromQuery])

  function n(v: string): number | null {
    return v === '' ? null : Number(v)
  }

  async function handleSave(e: SyntheticEvent) {
    e.preventDefault()
    setSaving(true)
    setError(null)
    try {
      const input = {
        quote_id: form.quote_id || null,
        client_id: form.client_id || null,
        end_client_id: form.end_client_id || null,
        po_number: form.po_number || null,
        po_received_date: form.po_received_date || null,
        start_date: form.start_date || null,
        end_date: form.end_date || null,
        quote_value: n(form.quote_value),
        po_value: n(form.po_value),
        difference: n(form.difference),
        quote_match: form.quote_match,
        vat: n(form.vat),
        total: n(form.total),
        rebate: n(form.rebate),
        net_value: n(form.net_value),
        invoiced_to_date: n(form.invoiced_to_date),
        timesheet_sent: null,
        outstanding_comments: form.outstanding_comments || null,
      }

      let savedId = id
      if (isEditing && id) {
        await updateSalesOrder(id, input)
      } else {
        const created = await createSalesOrder(input)
        savedId = created.id
      }
      navigate(`/staff/sales-orders/${savedId}`)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save sales order.')
    } finally {
      setSaving(false)
    }
  }

  if (loading) return <p className="text-sm text-text-muted">Loading…</p>

  return (
    <div className="max-w-xl">
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-xl font-semibold text-text">
          {isEditing ? `Edit sales order ${reference ?? ''}` : 'New sales order'}
        </h1>
        {isEditing && id && (
          <Button variant="secondary" onClick={() => navigate(`/staff/invoices/new?salesOrderId=${id}`)}>
            Create Invoice from this Sales Order
          </Button>
        )}
      </div>

      <Card>
        <form onSubmit={handleSave} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Client</Label>
              <Select value={form.client_id} onChange={(e) => setForm({ ...form, client_id: e.target.value })}>
                <option value="">—</option>
                {accounts.map((a) => (
                  <option key={a.id} value={a.id}>
                    {a.name}
                  </option>
                ))}
              </Select>
            </div>
            <div>
              <Label>End client</Label>
              <Select
                value={form.end_client_id}
                onChange={(e) => setForm({ ...form, end_client_id: e.target.value })}
              >
                <option value="">—</option>
                {accounts.map((a) => (
                  <option key={a.id} value={a.id}>
                    {a.name}
                  </option>
                ))}
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>PO number</Label>
              <Input value={form.po_number} onChange={(e) => setForm({ ...form, po_number: e.target.value })} />
            </div>
            <div>
              <Label>PO received date</Label>
              <Input
                type="date"
                value={form.po_received_date}
                onChange={(e) => setForm({ ...form, po_received_date: e.target.value })}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Start date</Label>
              <Input type="date" value={form.start_date} onChange={(e) => setForm({ ...form, start_date: e.target.value })} />
            </div>
            <div>
              <Label>End date</Label>
              <Input type="date" value={form.end_date} onChange={(e) => setForm({ ...form, end_date: e.target.value })} />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <Label>Quote value (£)</Label>
              <Input type="number" step="0.01" value={form.quote_value} onChange={(e) => setForm({ ...form, quote_value: e.target.value })} />
            </div>
            <div>
              <Label>PO value (£)</Label>
              <Input type="number" step="0.01" value={form.po_value} onChange={(e) => setForm({ ...form, po_value: e.target.value })} />
            </div>
            <div>
              <Label>Difference (£)</Label>
              <Input type="number" step="0.01" value={form.difference} onChange={(e) => setForm({ ...form, difference: e.target.value })} />
            </div>
          </div>

          <label className="flex items-center gap-2 text-sm text-text">
            <input
              type="checkbox"
              checked={form.quote_match}
              onChange={(e) => setForm({ ...form, quote_match: e.target.checked })}
            />
            Quote matches PO
          </label>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <Label>VAT (£)</Label>
              <Input type="number" step="0.01" value={form.vat} onChange={(e) => setForm({ ...form, vat: e.target.value })} />
            </div>
            <div>
              <Label>Total (£)</Label>
              <Input type="number" step="0.01" value={form.total} onChange={(e) => setForm({ ...form, total: e.target.value })} />
            </div>
            <div>
              <Label>Rebate (£)</Label>
              <Input type="number" step="0.01" value={form.rebate} onChange={(e) => setForm({ ...form, rebate: e.target.value })} />
            </div>
            <div>
              <Label>Net value (£)</Label>
              <Input type="number" step="0.01" value={form.net_value} onChange={(e) => setForm({ ...form, net_value: e.target.value })} />
            </div>
            <div>
              <Label>Invoiced to date (£)</Label>
              <Input
                type="number"
                step="0.01"
                value={form.invoiced_to_date}
                onChange={(e) => setForm({ ...form, invoiced_to_date: e.target.value })}
              />
            </div>
          </div>

          <div>
            <Label>Outstanding / comments</Label>
            <Textarea
              rows={3}
              value={form.outstanding_comments}
              onChange={(e) => setForm({ ...form, outstanding_comments: e.target.value })}
            />
          </div>

          <ErrorText>{error}</ErrorText>

          <Button type="submit" disabled={saving}>
            {saving ? 'Saving…' : 'Save sales order'}
          </Button>
        </form>
      </Card>
    </div>
  )
}
