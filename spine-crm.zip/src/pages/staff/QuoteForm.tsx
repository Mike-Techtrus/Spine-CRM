import { useEffect, useState, type SyntheticEvent } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { createQuote, getQuote, listAccounts, listOpportunities, updateQuote } from '../../lib/api'
import type { Account, OpportunityWithRelations, QuoteStatus } from '../../lib/types'
import { QUOTE_STATUS_LABELS } from '../../lib/types'
import { Button, Card, ErrorText, Input, Label, Select, Textarea } from '../../components/ui'

const emptyForm = {
  opportunity_id: '',
  client_id: '',
  end_client_id: '',
  quote_date: '',
  start_date: '',
  end_date: '',
  value: '',
  vat: '',
  total: '',
  rebate: '',
  net_value: '',
  status: 'draft' as QuoteStatus,
  comments: '',
}

export default function QuoteForm() {
  const { id } = useParams()
  const isEditing = Boolean(id)
  const navigate = useNavigate()

  const [accounts, setAccounts] = useState<Account[]>([])
  const [opportunities, setOpportunities] = useState<OpportunityWithRelations[]>([])
  const [quoteNumber, setQuoteNumber] = useState<string | null>(null)
  const [form, setForm] = useState(emptyForm)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    ;(async () => {
      try {
        const [accountList, oppList] = await Promise.all([listAccounts(true), listOpportunities()])
        setAccounts(accountList)
        setOpportunities(oppList)

        if (id) {
          const q = await getQuote(id)
          setQuoteNumber(q.quote_number)
          setForm({
            opportunity_id: q.opportunity_id ?? '',
            client_id: q.client_id ?? '',
            end_client_id: q.end_client_id ?? '',
            quote_date: q.quote_date ?? '',
            start_date: q.start_date ?? '',
            end_date: q.end_date ?? '',
            value: q.value?.toString() ?? '',
            vat: q.vat?.toString() ?? '',
            total: q.total?.toString() ?? '',
            rebate: q.rebate?.toString() ?? '',
            net_value: q.net_value?.toString() ?? '',
            status: q.status,
            comments: q.comments ?? '',
          })
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load.')
      } finally {
        setLoading(false)
      }
    })()
  }, [id])

  function toNumberOrNull(v: string): number | null {
    return v === '' ? null : Number(v)
  }

  async function handleSave(e: SyntheticEvent) {
    e.preventDefault()
    setSaving(true)
    setError(null)
    try {
      const input = {
        opportunity_id: form.opportunity_id || null,
        client_id: form.client_id || null,
        end_client_id: form.end_client_id || null,
        contact_id: null,
        quote_date: form.quote_date || null,
        start_date: form.start_date || null,
        end_date: form.end_date || null,
        value: toNumberOrNull(form.value),
        vat: toNumberOrNull(form.vat),
        total: toNumberOrNull(form.total),
        rebate: toNumberOrNull(form.rebate),
        net_value: toNumberOrNull(form.net_value),
        status: form.status,
        comments: form.comments || null,
      }

      if (isEditing && id) {
        await updateQuote(id, input)
      } else {
        await createQuote(input)
      }
      navigate('/staff/quotes')
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save quote.')
    } finally {
      setSaving(false)
    }
  }

  if (loading) return <p className="text-sm text-text-muted">Loading…</p>

  return (
    <div className="max-w-xl">
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-xl font-semibold text-text">
          {isEditing ? `Edit quote ${quoteNumber ?? ''}` : 'New quote'}
        </h1>
        {isEditing && id && (
          <Button variant="secondary" onClick={() => navigate(`/staff/sales-orders/new?quoteId=${id}`)}>
            Create Sales Order from this Quote
          </Button>
        )}
      </div>

      <Card>
        <form onSubmit={handleSave} className="space-y-4">
          <div>
            <Label>Opportunity</Label>
            <Select
              value={form.opportunity_id}
              onChange={(e) => setForm({ ...form, opportunity_id: e.target.value })}
            >
              <option value="">—</option>
              {opportunities.map((o) => (
                <option key={o.id} value={o.id}>
                  {o.name}
                </option>
              ))}
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Client</Label>
              <Select value={form.client_id} onChange={(e) => setForm({ ...form, client_id: e.target.value })}>
                <option value="">—</option>
                {accounts.map((a) => (
                  <option key={a.id} value={a.id}>
                    {a.name}
                  </option>
                ))}
              </Select>
            </div>
            <div>
              <Label>End client</Label>
              <Select
                value={form.end_client_id}
                onChange={(e) => setForm({ ...form, end_client_id: e.target.value })}
              >
                <option value="">—</option>
                {accounts.map((a) => (
                  <option key={a.id} value={a.id}>
                    {a.name}
                  </option>
                ))}
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <Label>Quote date</Label>
              <Input type="date" value={form.quote_date} onChange={(e) => setForm({ ...form, quote_date: e.target.value })} />
            </div>
            <div>
              <Label>Start date</Label>
              <Input type="date" value={form.start_date} onChange={(e) => setForm({ ...form, start_date: e.target.value })} />
            </div>
            <div>
              <Label>End date</Label>
              <Input type="date" value={form.end_date} onChange={(e) => setForm({ ...form, end_date: e.target.value })} />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <Label>Value (£)</Label>
              <Input type="number" step="0.01" value={form.value} onChange={(e) => setForm({ ...form, value: e.target.value })} />
            </div>
            <div>
              <Label>VAT (£)</Label>
              <Input type="number" step="0.01" value={form.vat} onChange={(e) => setForm({ ...form, vat: e.target.value })} />
            </div>
            <div>
              <Label>Total (£)</Label>
              <Input type="number" step="0.01" value={form.total} onChange={(e) => setForm({ ...form, total: e.target.value })} />
            </div>
            <div>
              <Label>Rebate (£)</Label>
              <Input type="number" step="0.01" value={form.rebate} onChange={(e) => setForm({ ...form, rebate: e.target.value })} />
            </div>
            <div>
              <Label>Net value (£)</Label>
              <Input type="number" step="0.01" value={form.net_value} onChange={(e) => setForm({ ...form, net_value: e.target.value })} />
            </div>
            <div>
              <Label>Status</Label>
              <Select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as QuoteStatus })}>
                {Object.entries(QUOTE_STATUS_LABELS).map(([value, label]) => (
                  <option key={value} value={value}>
                    {label}
                  </option>
                ))}
              </Select>
            </div>
          </div>

          <div>
            <Label>Comments</Label>
            <Textarea rows={3} value={form.comments} onChange={(e) => setForm({ ...form, comments: e.target.value })} />
          </div>

          <ErrorText>{error}</ErrorText>

          <Button type="submit" disabled={saving}>
            {saving ? 'Saving…' : 'Save quote'}
          </Button>
        </form>
      </Card>
    </div>
  )
}
