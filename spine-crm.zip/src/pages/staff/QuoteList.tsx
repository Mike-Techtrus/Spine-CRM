import { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { listQuotes } from '../../lib/api'
import type { QuoteWithRelations } from '../../lib/types'
import { QUOTE_STATUS_LABELS } from '../../lib/types'
import { Button, Card, StatusBadge } from '../../components/ui'

const STATUS_BADGE_MAP: Record<string, string> = {
  draft: 'draft',
  sent: 'submitted',
  accepted: 'approved',
  declined: 'rejected',
}

export default function QuoteList() {
  const navigate = useNavigate()
  const [quotes, setQuotes] = useState<QuoteWithRelations[] | null>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    listQuotes()
      .then(setQuotes)
      .catch((err) => setError(err instanceof Error ? err.message : 'Failed to load.'))
  }, [])

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-xl font-semibold text-text">Quotes</h1>
        <Link to="/staff/quotes/new">
          <Button>New quote</Button>
        </Link>
      </div>

      {error && <p className="text-sm text-danger">{error}</p>}
      {!quotes && !error && <p className="text-sm text-text-muted">Loading…</p>}
      {quotes && quotes.length === 0 && (
        <Card>
          <p className="text-sm text-text-muted">No quotes yet.</p>
        </Card>
      )}

      {quotes && quotes.length > 0 && (
        <div className="overflow-hidden rounded-lg border border-border">
          <table className="w-full text-sm">
            <thead className="bg-surface-raised text-left text-xs font-mono-label text-text-muted">
              <tr>
                <th className="px-4 py-2">Quote #</th>
                <th className="px-4 py-2">Client</th>
                <th className="px-4 py-2">End client</th>
                <th className="px-4 py-2">Net value</th>
                <th className="px-4 py-2">Status</th>
              </tr>
            </thead>
            <tbody>
              {quotes.map((q) => (
                <tr
                  key={q.id}
                  className="cursor-pointer border-t border-border hover:bg-surface-raised"
                  onClick={() => navigate(`/staff/quotes/${q.id}`)}
                >
                  <td className="px-4 py-2 font-mono-label text-text-muted">{q.quote_number}</td>
                  <td className="px-4 py-2 text-text">{q.client?.name || '—'}</td>
                  <td className="px-4 py-2 text-text-muted">{q.end_client?.name || '—'}</td>
                  <td className="px-4 py-2 text-text-muted">
                    {q.net_value ? `£${Number(q.net_value).toLocaleString('en-GB')}` : '—'}
                  </td>
                  <td className="px-4 py-2">
                    <StatusBadge status={STATUS_BADGE_MAP[q.status]} label={QUOTE_STATUS_LABELS[q.status]} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
