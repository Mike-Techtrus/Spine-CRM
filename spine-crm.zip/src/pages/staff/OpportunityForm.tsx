import { useEffect, useState, type SyntheticEvent } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { createOpportunity, getOpportunity, listAccounts, updateOpportunity } from '../../lib/api'
import type { Account, OpportunitySource, OpportunityStage } from '../../lib/types'
import { OPPORTUNITY_SOURCE_LABELS, OPPORTUNITY_STAGE_LABELS } from '../../lib/types'
import { Button, Card, ErrorText, Input, Label, Select, Textarea } from '../../components/ui'

const emptyForm = {
  name: '',
  billing_account_id: '',
  client_id: '',
  description: '',
  estimated_value: '',
  po_number: '',
  po_received: false,
  advanced_without_po: false,
  expected_close_date: '',
  source: '' as OpportunitySource | '',
  stage: 'qualifying' as OpportunityStage,
}

export default function OpportunityForm() {
  const { id } = useParams()
  const isEditing = Boolean(id)
  const navigate = useNavigate()

  const [accounts, setAccounts] = useState<Account[]>([])
  const [form, setForm] = useState(emptyForm)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    ;(async () => {
      try {
        const accountList = await listAccounts(true)
        setAccounts(accountList)

        if (id) {
          const opp = await getOpportunity(id)
          setForm({
            name: opp.name,
            billing_account_id: opp.billing_account_id ?? '',
            client_id: opp.client_id ?? '',
            description: opp.description ?? '',
            estimated_value: opp.estimated_value?.toString() ?? '',
            po_number: opp.po_number ?? '',
            po_received: opp.po_received,
            advanced_without_po: opp.advanced_without_po,
            expected_close_date: opp.expected_close_date ?? '',
            source: opp.source ?? '',
            stage: opp.stage,
          })
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load.')
      } finally {
        setLoading(false)
      }
    })()
  }, [id])

  async function handleSave(e: SyntheticEvent) {
    e.preventDefault()
    setSaving(true)
    setError(null)
    try {
      const input = {
        name: form.name,
        billing_account_id: form.billing_account_id || null,
        client_id: form.client_id || null,
        description: form.description || null,
        estimated_value: form.estimated_value ? Number(form.estimated_value) : null,
        po_number: form.po_number || null,
        po_received: form.po_received,
        advanced_without_po: form.advanced_without_po,
        expected_close_date: form.expected_close_date || null,
        source: form.source || null,
        stage: form.stage,
      }

      if (isEditing && id) {
        await updateOpportunity(id, input)
      } else {
        await createOpportunity(input)
      }
      navigate('/staff/opportunities')
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save opportunity.')
    } finally {
      setSaving(false)
    }
  }

  if (loading) return <p className="text-sm text-text-muted">Loading…</p>

  return (
    <div className="max-w-xl">
      <h1 className="mb-6 text-xl font-semibold text-text">{isEditing ? 'Edit opportunity' : 'New opportunity'}</h1>

      <Card>
        <form onSubmit={handleSave} className="space-y-4">
          <div>
            <Label>Name</Label>
            <Input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Client</Label>
              <Select
                value={form.billing_account_id}
                onChange={(e) => setForm({ ...form, billing_account_id: e.target.value })}
              >
                <option value="">—</option>
                {accounts.map((a) => (
                  <option key={a.id} value={a.id}>
                    {a.name}
                  </option>
                ))}
              </Select>
            </div>
            <div>
              <Label>End client</Label>
              <Select value={form.client_id} onChange={(e) => setForm({ ...form, client_id: e.target.value })}>
                <option value="">—</option>
                {accounts.map((a) => (
                  <option key={a.id} value={a.id}>
                    {a.name}
                  </option>
                ))}
              </Select>
            </div>
          </div>

          <div>
            <Label>Description</Label>
            <Textarea
              rows={3}
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Estimated value (£)</Label>
              <Input
                type="number"
                step="0.01"
                value={form.estimated_value}
                onChange={(e) => setForm({ ...form, estimated_value: e.target.value })}
              />
            </div>
            <div>
              <Label>Stage</Label>
              <Select value={form.stage} onChange={(e) => setForm({ ...form, stage: e.target.value as OpportunityStage })}>
                {Object.entries(OPPORTUNITY_STAGE_LABELS).map(([value, label]) => (
                  <option key={value} value={value}>
                    {label}
                  </option>
                ))}
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Source</Label>
              <Select
                value={form.source}
                onChange={(e) => setForm({ ...form, source: e.target.value as OpportunitySource })}
              >
                <option value="">—</option>
                {Object.entries(OPPORTUNITY_SOURCE_LABELS).map(([value, label]) => (
                  <option key={value} value={value}>
                    {label}
                  </option>
                ))}
              </Select>
            </div>
            <div>
              <Label>Expected close date</Label>
              <Input
                type="date"
                value={form.expected_close_date}
                onChange={(e) => setForm({ ...form, expected_close_date: e.target.value })}
              />
            </div>
          </div>

          <div>
            <Label>PO number (if received ahead of a formal quote/order)</Label>
            <Input value={form.po_number} onChange={(e) => setForm({ ...form, po_number: e.target.value })} />
          </div>

          <div className="flex gap-6">
            <label className="flex items-center gap-2 text-sm text-text">
              <input
                type="checkbox"
                checked={form.po_received}
                onChange={(e) => setForm({ ...form, po_received: e.target.checked })}
              />
              PO received
            </label>
            <label className="flex items-center gap-2 text-sm text-text">
              <input
                type="checkbox"
                checked={form.advanced_without_po}
                onChange={(e) => setForm({ ...form, advanced_without_po: e.target.checked })}
              />
              Advanced without PO
            </label>
          </div>

          <ErrorText>{error}</ErrorText>

          <Button type="submit" disabled={saving}>
            {saving ? 'Saving…' : 'Save opportunity'}
          </Button>
        </form>
      </Card>
    </div>
  )
}
