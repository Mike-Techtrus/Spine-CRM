import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { listAllTimesheets, listAccounts, listFieldEngineers } from '../../lib/api'
import type { Account, FieldEngineer, TimesheetEntryWithRelations, TimesheetStatus } from '../../lib/types'
import { DAY_TYPE_LABELS, STATUS_LABELS } from '../../lib/types'
import { Card, Select, StatusBadge } from '../../components/ui'

export default function AllTimesheets() {
  const navigate = useNavigate()
  const [timesheets, setTimesheets] = useState<TimesheetEntryWithRelations[] | null>(null)
  const [engineers, setEngineers] = useState<FieldEngineer[]>([])
  const [clients, setClients] = useState<Account[]>([])
  const [error, setError] = useState<string | null>(null)

  const [statusFilter, setStatusFilter] = useState<TimesheetStatus | ''>('submitted')
  const [engineerFilter, setEngineerFilter] = useState('')
  const [clientFilter, setClientFilter] = useState('')

  useEffect(() => {
    listFieldEngineers().then(setEngineers).catch(() => {})
    listAccounts(false).then(setClients).catch(() => {})
  }, [])

  useEffect(() => {
    ;(async () => {
      try {
        setTimesheets(
          await listAllTimesheets({
            status: statusFilter || undefined,
            fieldEngineerId: engineerFilter || undefined,
            clientId: clientFilter || undefined,
          }),
        )
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load timesheets.')
      }
    })()
  }, [statusFilter, engineerFilter, clientFilter])

  return (
    <div>
      <h1 className="mb-6 text-xl font-semibold text-text">Timesheets</h1>

      <Card className="mb-4">
        <div className="grid grid-cols-3 gap-4">
          <div>
            <label className="mb-1 block text-xs font-mono-label text-text-muted">Status</label>
            <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value as TimesheetStatus | '')}>
              <option value="">All</option>
              {Object.entries(STATUS_LABELS).map(([value, label]) => (
                <option key={value} value={value}>
                  {label}
                </option>
              ))}
            </Select>
          </div>
          <div>
            <label className="mb-1 block text-xs font-mono-label text-text-muted">Field engineer</label>
            <Select value={engineerFilter} onChange={(e) => setEngineerFilter(e.target.value)}>
              <option value="">All</option>
              {engineers.map((e) => (
                <option key={e.id} value={e.id}>
                  {e.name}
                </option>
              ))}
            </Select>
          </div>
          <div>
            <label className="mb-1 block text-xs font-mono-label text-text-muted">Client</label>
            <Select value={clientFilter} onChange={(e) => setClientFilter(e.target.value)}>
              <option value="">All</option>
              {clients.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </Select>
          </div>
        </div>
      </Card>

      {error && <p className="text-sm text-danger">{error}</p>}
      {!timesheets && !error && <p className="text-sm text-text-muted">Loading…</p>}

      {timesheets && timesheets.length === 0 && (
        <Card>
          <p className="text-sm text-text-muted">No timesheets match these filters.</p>
        </Card>
      )}

      {timesheets && timesheets.length > 0 && (
        <div className="overflow-hidden rounded-lg border border-border">
          <table className="w-full text-sm">
            <thead className="bg-surface-raised text-left text-xs font-mono-label text-text-muted">
              <tr>
                <th className="px-4 py-2">Ref</th>
                <th className="px-4 py-2">Date</th>
                <th className="px-4 py-2">Engineer</th>
                <th className="px-4 py-2">Client</th>
                <th className="px-4 py-2">Type</th>
                <th className="px-4 py-2">Status</th>
              </tr>
            </thead>
            <tbody>
              {timesheets.map((ts) => (
                <tr
                  key={ts.id}
                  className="cursor-pointer border-t border-border hover:bg-surface-raised"
                  onClick={() => navigate(`/staff/timesheets/${ts.id}`)}
                >
                  <td className="px-4 py-2 font-mono-label text-text-muted">{ts.reference}</td>
                  <td className="px-4 py-2 text-text">{ts.work_date}</td>
                  <td className="px-4 py-2 text-text">{ts.field_engineer.name}</td>
                  <td className="px-4 py-2 text-text">{ts.client.name}</td>
                  <td className="px-4 py-2 text-text-muted">{DAY_TYPE_LABELS[ts.day_type]}</td>
                  <td className="px-4 py-2">
                    <StatusBadge status={ts.status} label={STATUS_LABELS[ts.status]} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
