import { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { listSalesOrders } from '../../lib/api'
import type { SalesOrderWithRelations } from '../../lib/types'
import { Button, Card } from '../../components/ui'

export default function SalesOrderList() {
  const navigate = useNavigate()
  const [orders, setOrders] = useState<SalesOrderWithRelations[] | null>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    listSalesOrders()
      .then(setOrders)
      .catch((err) => setError(err instanceof Error ? err.message : 'Failed to load.'))
  }, [])

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-xl font-semibold text-text">Sales Orders</h1>
        <Link to="/staff/sales-orders/new">
          <Button>New sales order</Button>
        </Link>
      </div>

      {error && <p className="text-sm text-danger">{error}</p>}
      {!orders && !error && <p className="text-sm text-text-muted">Loading…</p>}
      {orders && orders.length === 0 && (
        <Card>
          <p className="text-sm text-text-muted">No sales orders yet.</p>
        </Card>
      )}

      {orders && orders.length > 0 && (
        <div className="overflow-hidden rounded-lg border border-border">
          <table className="w-full text-sm">
            <thead className="bg-surface-raised text-left text-xs font-mono-label text-text-muted">
              <tr>
                <th className="px-4 py-2">Ref</th>
                <th className="px-4 py-2">Client</th>
                <th className="px-4 py-2">End client</th>
                <th className="px-4 py-2">PO number</th>
                <th className="px-4 py-2">Net value</th>
                <th className="px-4 py-2">Invoiced to date</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((o) => (
                <tr
                  key={o.id}
                  className="cursor-pointer border-t border-border hover:bg-surface-raised"
                  onClick={() => navigate(`/staff/sales-orders/${o.id}`)}
                >
                  <td className="px-4 py-2 font-mono-label text-text-muted">{o.reference}</td>
                  <td className="px-4 py-2 text-text">{o.client?.name || '—'}</td>
                  <td className="px-4 py-2 text-text-muted">{o.end_client?.name || '—'}</td>
                  <td className="px-4 py-2 text-text-muted">{o.po_number || '—'}</td>
                  <td className="px-4 py-2 text-text-muted">
                    {o.net_value ? `£${Number(o.net_value).toLocaleString('en-GB')}` : '—'}
                  </td>
                  <td className="px-4 py-2 text-text-muted">
                    {o.invoiced_to_date ? `£${Number(o.invoiced_to_date).toLocaleString('en-GB')}` : '—'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
