import { useEffect, useState, type FormEvent } from 'react'
import { createFieldEngineer, listFieldEngineers, updateFieldEngineer } from '../../lib/api'
import type { FieldEngineer } from '../../lib/types'
import { Button, Card, ErrorText, Input, Label } from '../../components/ui'

const emptyForm = { name: '', email: '', phone: '', day_rate: '' }

export default function FieldEngineers() {
  const [engineers, setEngineers] = useState<FieldEngineer[]>([])
  const [form, setForm] = useState(emptyForm)
  const [error, setError] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)

  async function refresh() {
    setEngineers(await listFieldEngineers())
  }

  useEffect(() => {
    refresh().catch((err) => setError(err instanceof Error ? err.message : 'Failed to load.'))
  }, [])

  async function handleAdd(e: FormEvent) {
    e.preventDefault()
    setSaving(true)
    setError(null)
    try {
      await createFieldEngineer({
        name: form.name,
        email: form.email,
        phone: form.phone || null,
        day_rate: form.day_rate ? Number(form.day_rate) : null,
      })
      setForm(emptyForm)
      await refresh()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to add field engineer.')
    } finally {
      setSaving(false)
    }
  }

  async function toggleActive(engineer: FieldEngineer) {
    await updateFieldEngineer(engineer.id, { is_active: !engineer.is_active })
    await refresh()
  }

  async function linkLogin(engineer: FieldEngineer) {
    const userId = window.prompt(
      `Paste the Supabase auth user UUID for ${engineer.name} (Supabase Dashboard → Authentication → Users, after inviting ${engineer.email}).`,
      engineer.user_id ?? '',
    )
    if (userId === null) return
    await updateFieldEngineer(engineer.id, { user_id: userId.trim() || null })
    await refresh()
  }

  return (
    <div>
      <h1 className="mb-6 text-xl font-semibold text-text">Field Engineers</h1>

      <Card className="mb-6">
        <form onSubmit={handleAdd} className="grid grid-cols-4 items-end gap-4">
          <div>
            <Label>Name</Label>
            <Input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          </div>
          <div>
            <Label>Email</Label>
            <Input
              required
              type="email"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
            />
          </div>
          <div>
            <Label>Phone</Label>
            <Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
          </div>
          <div>
            <Label>Day rate (£)</Label>
            <Input
              type="number"
              step="0.01"
              value={form.day_rate}
              onChange={(e) => setForm({ ...form, day_rate: e.target.value })}
            />
          </div>
          <div className="col-span-4">
            <Button type="submit" disabled={saving}>
              {saving ? 'Adding…' : 'Add field engineer'}
            </Button>
          </div>
        </form>
        <ErrorText>{error}</ErrorText>
      </Card>

      <div className="overflow-hidden rounded-lg border border-border">
        <table className="w-full text-sm">
          <thead className="bg-surface-raised text-left text-xs font-mono-label text-text-muted">
            <tr>
              <th className="px-4 py-2">Name</th>
              <th className="px-4 py-2">Email</th>
              <th className="px-4 py-2">Day rate</th>
              <th className="px-4 py-2">Login</th>
              <th className="px-4 py-2">Status</th>
              <th className="px-4 py-2"></th>
            </tr>
          </thead>
          <tbody>
            {engineers.map((e) => (
              <tr key={e.id} className="border-t border-border">
                <td className="px-4 py-2 text-text">{e.name}</td>
                <td className="px-4 py-2 text-text-muted">{e.email}</td>
                <td className="px-4 py-2 text-text-muted">{e.day_rate ? `£${Number(e.day_rate).toFixed(2)}` : '—'}</td>
                <td className="px-4 py-2">
                  <button onClick={() => linkLogin(e)} className="text-xs text-accent hover:underline">
                    {e.user_id ? 'Linked' : 'Link login…'}
                  </button>
                </td>
                <td className="px-4 py-2 text-text-muted">{e.is_active ? 'Active' : 'Inactive'}</td>
                <td className="px-4 py-2 text-right">
                  <button onClick={() => toggleActive(e)} className="text-xs text-text-muted hover:text-text">
                    {e.is_active ? 'Deactivate' : 'Reactivate'}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <p className="mt-4 text-xs text-text-muted">
        To give a field engineer a login: invite their email from the Supabase Dashboard
        (Authentication → Users → Invite), including <code>role: field_engineer</code> and their{' '}
        <code>full_name</code> in the invite's user metadata, then click "Link login…" above and paste
        their new user UUID.
      </p>
    </div>
  )
}
