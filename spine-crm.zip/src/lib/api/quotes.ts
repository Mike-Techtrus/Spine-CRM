import { supabase } from '../supabaseClient'
import type { Quote, QuoteWithRelations } from '../types'
import { unwrap } from './_shared'

const WITH_RELATIONS_SELECT = `
  *,
  client:accounts!quotes_client_id_fkey(id, name),
  end_client:accounts!quotes_end_client_id_fkey(id, name),
  opportunity:opportunities(id, name)
`

export async function listQuotes(): Promise<QuoteWithRelations[]> {
  return unwrap(
    await supabase.from('quotes').select(WITH_RELATIONS_SELECT).order('created_at', { ascending: false }),
  )
}

export async function getQuote(id: string): Promise<QuoteWithRelations> {
  return unwrap(await supabase.from('quotes').select(WITH_RELATIONS_SELECT).eq('id', id).single())
}

export type QuoteInput = Omit<Quote, 'id' | 'quote_number' | 'created_at' | 'updated_at'>

export async function createQuote(input: Partial<QuoteInput>): Promise<Quote> {
  return unwrap(await supabase.from('quotes').insert(input).select().single())
}

export async function updateQuote(id: string, input: Partial<QuoteInput>): Promise<Quote> {
  return unwrap(await supabase.from('quotes').update(input).eq('id', id).select().single())
}
